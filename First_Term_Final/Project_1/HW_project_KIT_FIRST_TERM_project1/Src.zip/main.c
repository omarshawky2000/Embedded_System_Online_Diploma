#include <stdint.h>
#include <stdio.h>

#include "driver/driver.h"

int main (){
	GPIO_INITIALIZATION();
	while (1)
	{
		//Implement your Design 
	}

}
